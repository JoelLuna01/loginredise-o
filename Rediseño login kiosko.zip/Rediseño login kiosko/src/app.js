/* ==========================================================================
   MIA — Módulo Inteligente de Autoservicio (Embotelladora Aga)
   Kiosco de Recursos Humanos — Front-end

   Estados del flujo:
     idle     → Pantalla inicial, botón "Iniciar reconocimiento" visible.
     scanning → Cámara activa, buscando rostro.
     detected → Rostro identificado, barra de progreso (~2 s).
     success  → Acceso concedido, fade de transición al portal.
     failed   → No se identificó, botón reaparece para reintentar.

   PROTECCIÓN: El reconocimiento facial NO está activo permanentemente.
   Solo se activa cuando el usuario presiona el botón.
   ========================================================================== */

const $ = (sel) => document.querySelector(sel);

// ── Elementos del DOM ────────────────────────────────────────────────────
const scanner         = $("#scanner");
const startBtn        = $("#startBtn");
const idleText        = $("#idleText");
const scanningText    = $("#scanningText");
const detectedText    = $("#detectedText");
const successText     = $("#successText");
const failedText      = $("#failedText");
const progressBar     = $("#progressBar");
const clock           = $("#clock");
const dateEl          = $("#date");
const particles       = $("#particles");
const companyLogo     = $("#companyLogo");
const logoFallback    = $("#logoFallback");
const portalOverlay   = $("#portalOverlay");
const faceStatusBadge = $("#faceStatusBadge");
const faceStatusLabel = $("#faceStatusLabel");
const aiDot           = $("#aiDot");
const aiLabel         = $("#aiLabel");
const employeeName    = $("#employeeName");

const allCopyBlocks = [idleText, scanningText, detectedText, successText, failedText];

// ── Estado global ────────────────────────────────────────────────────────
let state = "idle";
let scanTimeout = null;
let inactivityTimer = null;

// Configuración (ajustar según necesidades del backend)
const SCAN_DURATION_MS    = 6000;  // Tiempo que se busca un rostro antes de fallar
const PROGRESS_DURATION   = 2000;  // Duración de la barra de progreso
const INACTIVITY_TIMEOUT  = 60000; // 60 s de inactividad → vuelve a idle
const PORTAL_REDIRECT_URL = null;  // Poner URL del portal real, ej. "/portal"

// ── Reloj ────────────────────────────────────────────────────────────────
function updateClock() {
  const now = new Date();
  clock.textContent = now.toLocaleTimeString("es-MX", {
    hour: "2-digit",
    minute: "2-digit",
  });
  dateEl.textContent = now.toLocaleDateString("es-MX", {
    weekday: "long",
    year: "numeric",
    month: "long",
    day: "numeric",
  });
}

// ── Partículas de fondo ──────────────────────────────────────────────────
function createParticles() {
  for (let i = 0; i < 18; i++) {
    const p = document.createElement("span");
    const size = Math.random() * 4 + 2;
    p.className = "particle";
    p.style.width  = size + "px";
    p.style.height = size + "px";
    p.style.left   = Math.random() * 100 + "%";
    p.style.top    = Math.random() * 100 + "%";
    p.style.animationDelay    = Math.random() * 5 + "s";
    p.style.animationDuration = (Math.random() * 8 + 8) + "s";
    p.style.opacity = (Math.random() * 0.12 + 0.04).toString();
    particles.appendChild(p);
  }
}

// ── Logo fallback ────────────────────────────────────────────────────────
function setupLogoFallback() {
  companyLogo.addEventListener("error", () => {
    companyLogo.style.display = "none";
    logoFallback.style.display = "block";
  });
  companyLogo.addEventListener("load", () => {
    logoFallback.style.display = "none";
  });
}

// ── Mostrar solo un bloque de texto ──────────────────────────────────────
function showOnly(el) {
  allCopyBlocks.forEach((block) => {
    block.classList.toggle("is-visible", block === el);
  });
}

// ── Actualizar indicadores del header y footer ───────────────────────────
function updateIndicators() {
  // Header badge
  faceStatusBadge.classList.remove("is-scanning", "is-success");

  if (state === "scanning") {
    faceStatusBadge.classList.add("is-scanning");
    faceStatusLabel.textContent = "Escaneando…";
  } else if (state === "detected" || state === "success") {
    faceStatusBadge.classList.add("is-success");
    faceStatusLabel.textContent = "Identificado";
  } else {
    faceStatusLabel.textContent = "En espera";
  }

  // Footer AI dot
  if (state === "scanning") {
    aiDot.classList.remove("dot-idle");
    aiLabel.textContent = "IA activa";
  } else if (state === "detected" || state === "success") {
    aiDot.classList.remove("dot-idle");
    aiLabel.textContent = "IA activa";
  } else {
    aiDot.classList.add("dot-idle");
    aiLabel.textContent = "IA en espera";
  }
}

// ── Cambio de estado principal ───────────────────────────────────────────
function setState(next) {
  // Limpiar timers previos
  if (scanTimeout) {
    clearTimeout(scanTimeout);
    scanTimeout = null;
  }
  clearInactivityTimer();

  state = next;

  // Clases del scanner
  scanner.classList.remove("scanner-idle", "scanning", "detected", "success", "failed");

  switch (state) {
    case "idle":
      scanner.classList.add("scanner-idle");
      showOnly(idleText);
      progressBar.style.width = "0%";
      portalOverlay.classList.remove("is-active");
      break;

    case "scanning":
      scanner.classList.add("scanning");
      showOnly(scanningText);
      startScanTimer();
      break;

    case "detected":
      scanner.classList.add("detected");
      showOnly(detectedText);
      runProgress();
      break;

    case "success":
      scanner.classList.add("success");
      showOnly(successText);
      triggerPortalTransition();
      break;

    case "failed":
      scanner.classList.add("failed");
      showOnly(failedText);
      // Tras unos segundos vuelve a idle automáticamente si no interactúa
      startInactivityTimer(8000);
      break;
  }

  updateIndicators();
}

// ── Temporizador de escaneo (simula búsqueda de rostro) ──────────────────
function startScanTimer() {
  /* ===================================================================
     ===> INTEGRACIÓN BACKEND <===
     Reemplazar este setTimeout por la lógica real de reconocimiento:

     1. Iniciar stream de cámara.
     2. Enviar frames al servicio de reconocimiento (Azure Face, etc.).
     3. Si identifica:
          employeeName.textContent = nombreReal;
          setState("detected");
     4. Si falla o timeout:
          setState("failed");
     =================================================================== */

  scanTimeout = setTimeout(() => {
    // ── SIMULACIÓN ──
    // 70% probabilidad de éxito para demostrar ambos flujos.
    // Cambiar a 100% para demo solo de éxito, o conectar al backend real.
    const success = Math.random() < 0.7;

    if (success) {
      employeeName.textContent = "Juan Pérez";
      setState("detected");
    } else {
      setState("failed");
    }
  }, SCAN_DURATION_MS);
}

// ── Barra de progreso tras identificación ────────────────────────────────
function runProgress() {
  const start = performance.now();

  function step(now) {
    const elapsed = now - start;
    const pct = Math.min((elapsed / PROGRESS_DURATION) * 100, 100);
    progressBar.style.width = pct + "%";

    if (elapsed < PROGRESS_DURATION) {
      requestAnimationFrame(step);
    } else {
      setState("success");
    }
  }

  requestAnimationFrame(step);
}

// ── Transición al portal ─────────────────────────────────────────────────
function triggerPortalTransition() {
  portalOverlay.classList.add("is-active");

  setTimeout(() => {
    if (PORTAL_REDIRECT_URL) {
      // Redirigir al portal real de Fortia / autoservicio
      window.location.href = PORTAL_REDIRECT_URL;
    } else {
      // Demo: vuelve a idle después de la transición
      setTimeout(() => {
        setState("idle");
      }, 1200);
    }
  }, 800);
}

// ── Auto-cierre de sesión por inactividad ─────────────────────────────────
function startInactivityTimer(ms) {
  clearInactivityTimer();
  inactivityTimer = setTimeout(() => {
    setState("idle");
  }, ms || INACTIVITY_TIMEOUT);
}

function clearInactivityTimer() {
  if (inactivityTimer) {
    clearTimeout(inactivityTimer);
    inactivityTimer = null;
  }
}

// ── Eventos ──────────────────────────────────────────────────────────────

// Botón principal: Iniciar reconocimiento
startBtn.addEventListener("click", () => {
  if (state === "idle" || state === "failed") {
    setState("scanning");
  }
});

// Soporte
$("#languageButton").addEventListener("click", () => {
  alert("Cambio de idioma pendiente de conectar con backend.");
});

$("#helpButton").addEventListener("click", () => {
  alert("Solicitud de ayuda pendiente de conectar con backend.");
});

// ── Inicialización ───────────────────────────────────────────────────────
updateClock();
createParticles();
setupLogoFallback();
setInterval(updateClock, 1000);

// Arranca en estado idle (botón visible, escáner inactivo)
setState("idle");
